// Playground - noun: a place where people can play

import UIKit

var guests = ["Jon", "Kim", "Kailey", "Kara"]

guests.map({
    (name: String) -> Void in println("Hello \(name)")
})

guests.map({println("Hello \($0)")})

var messages = guests.map({
    (name:String) -> String in return "Welcome \(name)"
})

for message in messages {
    println(message)
}


var greetGuest = { (name:String) -> Void in
    println("Hello guest named \(name)")
}

var sayGoodbye = { (name:String) -> Void in
    println("Goodbye \(name)")
}


guests.map(greetGuest)
guests.map(sayGoodbye)
    



var greetGuest2 = { (name:String) -> Void in
    if (name.hasPrefix("K")) {
        println("\(name) is on the guest list")
    } else {
        println("\(name) was not invited")
    }
}

guests.map(greetGuest2)

func temperatures(calculate:(Int)->Void) {
        var numbers = [72,74,76,68,70,72,66]
        numbers.map(calculate)
}

func testFunction() {
    var total = 0
    var count = 0
    let addTemps = {
        (num: Int) -> Void in
        total += num
        count++
    }
    temperatures(addTemps)
    println("Total: \(total)")
    println("Count: \(count)")
    println("Average: \(total/count)")
}

testFunction()


