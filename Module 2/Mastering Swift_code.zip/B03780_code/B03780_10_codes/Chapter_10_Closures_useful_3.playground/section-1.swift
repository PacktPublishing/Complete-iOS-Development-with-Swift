// Playground - noun: a place where people can play

import UIKit



class TestClass {
    typealias compareClosure = ((String) -> Void)

    func isGreater(numOne: Int, numTwo:Int, successHandler: compareClosure, failureHandler: compareClosure) {
        if numOne > numTwo {
            successHandler("\(numOne) is greater than \(numTwo)")
        } else {
            failureHandler("\(numOne) is not greater than \(numTwo)")
        }

    }
}

var success: TestClass.compareClosure = {
    println("Success: \($0)")
}

var failure: TestClass.compareClosure = {
    println("Failure: \($0)")
}

var test = TestClass()
test.isGreater(6, numTwo: 8, successHandler:success, failureHandler:failure)


