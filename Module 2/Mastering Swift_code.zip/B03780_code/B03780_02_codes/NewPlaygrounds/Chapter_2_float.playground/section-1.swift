// Playground - noun: a place where people can play

import UIKit

var x: Float = 3.14

var y = 3.14

println(x)
