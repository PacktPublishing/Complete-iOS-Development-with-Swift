// Playground - noun: a place where people can play
import UIKit

//Option Variable
var stringOne : String?
//Non-Optional Variable
var stringTwo : String

stringOne = nil
stringTwo = nil

