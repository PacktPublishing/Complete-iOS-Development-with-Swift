// Playground - noun: a place where people can play

import UIKit

enum Planets {    case Mercury, Venus, Earth, Mars, Jupiter    case Saturn, Uranus, Neptune}


var planetWeLiveOn = Planets.Earth
var furthestPlanet = Planets.Neptune
planetWeLiveOn = .Mars

if planetWeLiveOn == .Mars {
    println("Mars it is")
}


switch planetWeLiveOn {
    case .Mercury:
    println("We live on Mercury, it is very hot!")
    case .Venus:
    println("We live on Venus, it is very hot!")
    case .Earth:
        println("We live on Earth, just right")
    case .Mars:
        println("We live on Mars, a little cold")
    default:
        println("Where do we live?")
    }


enum Devices: String {            case iPod = "iPod"            case iPhone = "iPhone"            case iPad = "iPad"}println("We are using a " + Devices.iPad.rawValue)