// Playground - noun: a place where people can play

import UIKit

var stringA = "Jon"
var stringB = "Hello \(stringA)"

var x = "Hello"let y = "HI"var z = " World"//This is valid, x is mutablex += z//This is invalid, y is not mutable.//y += z

