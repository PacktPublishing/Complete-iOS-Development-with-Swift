// Playground - noun: a place where people can play

import UIKit

var a = UInt8.max
var b = UInt8.min

var c = UInt16.max
var d = UInt16.min

var e = UInt32.max
var f = UInt32.min

var g = UInt64.max
var h = UInt64.min

var j = UInt.max
var k = UInt.min

var l = Int8.max
var m = Int8.min

var n = Int16.max
var o = Int16.min

var p = Int32.max
var q = Int32.min

var r = Int64.max
var s = Int64.min

var t = Int.max
var u = Int.min
