// Playground - noun: a place where people can play

import UIKit

var a : Int = 3var b : Double = 0.14var c = Double(a) + b
println(c)
