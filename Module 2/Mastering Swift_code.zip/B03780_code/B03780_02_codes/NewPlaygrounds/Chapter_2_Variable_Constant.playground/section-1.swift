// Playground - noun: a place where people can play

import UIKit

//Constantslet freezingTempertureWaterCelsius = 0let speedOfLightKmSec = 300000//Variablesvar currentTemperture = 22var currentSpeed = 55
