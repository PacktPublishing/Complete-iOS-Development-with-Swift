// Playground - noun: a place where people can play

import UIKit

//Optional Variable
var stringOne : String?

//--------stringOne is nil ---------------//
//Explicitly check for nil
if stringOne != nil {
    println(stringOne)
} else {
    println("Explicit Check:  stringOne is nil")
}

//option binding
if let tmp = stringOne {
    println(tmp)
} else {
    println("Optional Binding: stringOne is nil")
}

//Optional chainging
var newString = stringOne?.lastPathComponent


//--------adding value to stringONe ---------------//
stringOne = "http://www.packetpub.com/all"

//--------stringOne is nil ---------------//
//Explicitly check for nil
if stringOne != nil {
    println(stringOne)
} else {
    println("Explicit Check:  stringOne is nil")
}

//option binding
if let tmp = stringOne {
    println(tmp)
} else {
    println("Optional Binding: stringOne is nil")
}

//Optional chainging
var pathString = stringOne?.lastPathComponent

