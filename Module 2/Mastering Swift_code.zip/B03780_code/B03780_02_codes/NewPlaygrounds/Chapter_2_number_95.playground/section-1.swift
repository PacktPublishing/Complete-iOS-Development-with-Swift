// Playground - noun: a place where people can play

import UIKit

var z = 95
var b = 0b1011111
var c = 0o137
var d = 0x5f
