// Playground - noun: a place where people can play

import UIKit

var stringOne = "one,two,three,four"println(stringOne.stringByReplacingOccurrencesOfString("to", withString: "two", options: nil))



var path = "/one/two/three/four"
//Create start and end indexes
var startIndex = advance(path.startIndex, 4)
var endIndex = advance(path.startIndex, 14)

path.substringWithRange(Range<String.Index>(start:startIndex, end:endIndex))   //returns the String /two/three

path.substringToIndex(startIndex)  //returns the String /one
path.substringFromIndex(endIndex)  //returns the String /four
last(path)  //returns the last character in the String r
first(path)  //returns the first character in the String /

var length = count(path)

path.pathComponents  //returns an array containing “/”,”one”,”two”,”three”,”four”path.stringByAppendingPathComponent("five") //returns a new string containing /one/two/three/four/fivepath.stringByDeletingLastPathComponent  //returns a new string containint /one/two/threepath.lastPathComponent