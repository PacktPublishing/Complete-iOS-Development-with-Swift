// Playground - noun: a place where people can play

import UIKit

var stringOne = "hElLo"
println("capitalizedString:  " + stringOne.capitalizedString)
println("lowercaseStrig:" + stringOne.lowercaseString)
println("uppercaseString" + stringOne.uppercaseString)

