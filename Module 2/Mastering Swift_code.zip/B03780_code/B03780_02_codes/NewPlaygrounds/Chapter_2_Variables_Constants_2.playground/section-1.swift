// Playground - noun: a place where people can play

import UIKit

//Constantslet freezingTempertureWaterCelsius = 0, speedOfLightKmSec = 300000//Variablesvar currentTemperture = 22, currentSpeed = 55
