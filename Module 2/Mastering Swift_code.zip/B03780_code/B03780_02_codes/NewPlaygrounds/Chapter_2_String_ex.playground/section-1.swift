// Playground - noun: a place where people can play

import UIKit

var stringOne = "Hello"

for char in stringOne {
    println(char)
}

