// Playground - noun: a place where people can play

import UIKit

var myOptional: String?

if let temp = myOptional {
    println(temp)
    println("Cannot use temp outside of this context")
} else {
    println("myOptional is nil")
}
