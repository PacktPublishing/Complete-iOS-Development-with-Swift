// Playground - noun: a place where people can play

import UIKit

var integerVar = 10
integerVar = "My String"
