// Playground - noun: a place where people can play

import UIKit

let isSwiftCool = truevar itIsRaining = falseif isSwiftCool {
    println("Yea, I cannot wait to learn it")
}if (itIsRaining) {    println("Get a rain coat")}

