// Playground - noun: a place where people can play

import UIKit

protocol TV {
    var currentChannel: Int {get}
    
    func turnOn()
    func turnOff()
    func changeChannel(channel: Int)
}

protocol RemoteControl {
    var tv: TV {get set}
    
    func turnOn()
    func turnOff()
    func setChannel(channel: Int)
    func nextChannel()
    func prevChannel()
}

class VizioTV: TV {
    
    var currentChannel = 1
    
    func turnOn() {
        println("Vizio On")
    }
    func turnOff() {
        println("Vizio Off")
    }
    func changeChannel(channel: Int) {
        self.currentChannel = channel
    }
}

class SonyTV: TV {
    
    var currentChannel = 1
    
    func turnOn() {
        println("Sony On")
    }
    func turnOff() {
        println("Sony Off")
    }
    func changeChannel(channel: Int) {
        self.currentChannel = channel
    }
}

class MyUniversalRemote: RemoteControl {
    var tv: TV
    
    init(tv: TV) {
        self.tv = tv
    }
    
    func turnOn() {
        tv.turnOn()
    }
    func turnOff() {
        tv.turnOff()
    }
    func setChannel(channel: Int) {
        tv.changeChannel(channel)
    }
    func nextChannel() {
        tv.changeChannel(tv.currentChannel + 1)
    }
    func prevChannel() {
        tv.changeChannel(tv.currentChannel - 1)
    }
}

var myTv = VizioTV()
var remote = MyUniversalRemote(tv: myTv)
remote.turnOn()
remote.nextChannel()
remote.turnOff()
