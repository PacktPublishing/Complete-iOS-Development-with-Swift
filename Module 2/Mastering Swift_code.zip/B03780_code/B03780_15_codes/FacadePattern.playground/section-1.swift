// Playground - noun: a place where people can play

import UIKit

class HotelBooking {
    func getHotelNameForDates(to: NSDate, from: NSDate) -> [String]? {
        var hotels = [String]()
        //logic to get hotels
        return hotels
    }
}

class FlightBooking {
    func getFlightNameForDates(to: NSDate, from: NSDate) -> [String]? {
        var flights = [String]()
        //logic to get flights
        return flights
    }
}

class RentalCarBooking {
    func getRentalCarNameForDates(to: NSDate, from: NSDate) -> [String]? {
        var cars = [String]()
        //logic to get flights
        return cars
    }
}


class TravelFacade {
    var hotels = HotelBooking()
    var flights = FlightBooking()
    var rentalCars = RentalCarBooking()
    
    init(to: NSDate, from: NSDate) {
        hotels.getHotelNameForDates(to, from: from)
        flights.getFlightNameForDates(to, from: from)
        rentalCars.getRentalCarNameForDates(to, from: from)
    }
}