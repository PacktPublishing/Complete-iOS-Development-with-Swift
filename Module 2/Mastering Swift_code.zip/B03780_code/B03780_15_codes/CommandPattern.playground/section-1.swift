// Playground - noun: a place where people can play

import UIKit

protocol Command {
    func execute()
}

class LightOnCommand: Command {
    func execute() {
        println("Turning Light On")
    }
}

class LightOffCommand: Command {
    func execute() {
        println("Turning Light Off")
    }
}

class Light {
    private var lightOnCommand: Command
    private var lightOffCommand: Command
    
    init(lightOnCommand: Command, lightOffCommand: Command) {
        self.lightOnCommand = lightOnCommand
        self.lightOffCommand = lightOffCommand
    }
    
    func turnOnLight() {
        self.lightOnCommand.execute()
    }
    
    func turnOffLight() {
        self.lightOffCommand.execute()
    }
}


var on = LightOnCommand()
var off = LightOffCommand()
var light = Light(lightOnCommand: on, lightOffCommand: off)

light.turnOnLight()
light.turnOffLight()
