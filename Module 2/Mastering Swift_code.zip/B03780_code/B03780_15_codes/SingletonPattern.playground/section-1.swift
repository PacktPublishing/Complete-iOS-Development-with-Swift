// Playground - noun: a place where people can play

import UIKit

class MySingleton {
    
    var number = 0
    
    private init() {}
    
    class var sharedInstance: MySingleton {
        struct Singleton {
            static let instance = MySingleton()
        }
        return Singleton.instance
    }
}

var singleA = MySingleton.sharedInstance
singleA.number = 1

var singleB = MySingleton.sharedInstance
singleB.number = 2

println(singleA.number)
println(singleB.number)

var singleC = MySingleton.sharedInstance
singleB.number = 3

println(singleA.number)
println(singleB.number)
println(singleC.number)
