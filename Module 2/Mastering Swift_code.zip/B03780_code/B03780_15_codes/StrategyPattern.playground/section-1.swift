// Playground - noun: a place where people can play

import UIKit

protocol CompressionStrategy {
    func compressFiles(filePaths: [String])
}

class ZipCompressionStrategy: CompressionStrategy {
    func compressFiles(filePaths: [String]) {
        println("Using Zip Compression")
    }
}

class RarCompressionStrategy: CompressionStrategy {
    func compressFiles(filePaths: [String]) {
        println("Using RAR Compression")
    }
}

class CompressContent {
    var strategy: CompressionStrategy
    
    init(strategy: CompressionStrategy) {
        self.strategy = strategy
    }
    
    func compressFiles(filePaths: [String]) {
        self.strategy.compressFiles(filePaths)
    }
}

var filePaths = ["file1.txt", "file2.txt"]
var zip = ZipCompressionStrategy()
var rar = RarCompressionStrategy()

var compress = CompressContent(strategy: zip)
compress.compressFiles(filePaths)

compress.strategy = rar
compress.compressFiles(filePaths)


