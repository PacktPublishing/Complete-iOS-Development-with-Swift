// Playground - noun: a place where people can play

import UIKit

class BurgerOld {
    let name: String
    let patties: Int
    let bacon: Bool
    let cheese: Bool
    let pickles: Bool
    let ketchup: Bool
    let mustard: Bool
    let lettuce: Bool
    let tomato: Bool
    
    init(name: String, patties: Int, bacon: Bool, cheese: Bool, pickles: Bool,ketchup: Bool,mustard: Bool,lettuce: Bool,tomato: Bool) {
        self.name = name
        self.patties = patties
        self.bacon = bacon
        self.cheese = cheese
        self.pickles = pickles
        self.ketchup = ketchup
        self.mustard = mustard
        self.lettuce = lettuce
        self.tomato = tomato
    }
    
    func showBurger() {
        println("Name:    \(name)")
        println("Patties: \(patties)")
        println("Bacon:   \(bacon)")
        println("Cheese:  \(cheese)")
        println("Pickles: \(pickles)")
        println("Ketchup: \(ketchup)")
        println("Mustard: \(mustard)")
        println("Lettuce: \(lettuce)")
        println("Tomato:   \(tomato)")
    }
}

var burgerOld = BurgerOld(name: "My Burger", patties: 1, bacon: false, cheese: false, pickles: false, ketchup: false, mustard: false, lettuce: false, tomato: false)
burgerOld.showBurger()

class Burger {
    let name: String
    let patties: Int
    let bacon: Bool
    let cheese: Bool
    let pickles: Bool
    let ketchup: Bool
    let mustard: Bool
    let lettuce: Bool
    let tomato: Bool
    
    init(builder: BurgerBuilder) {
        self.name = builder.name
        self.patties = builder.patties
        self.bacon = builder.bacon
        self.cheese = builder.cheese
        self.pickles = builder.pickles
        self.ketchup = builder.ketchup
        self.mustard = builder.mustard
        self.lettuce = builder.lettuce
        self.tomato = builder.tomato
    }
    
    func showBurger() {
        println("Name:    \(name)")
        println("Patties: \(patties)")
        println("Bacon:   \(bacon)")
        println("Cheese:  \(cheese)")
        println("Pickles: \(pickles)")
        println("Ketchup: \(ketchup)")
        println("Mustard: \(mustard)")
        println("Lettuce: \(lettuce)")
        println("Tomato:  \(tomato)")
        
    }
}

protocol BurgerBuilder {
    var name: String {get set}
    var patties: Int {get set}
    var bacon: Bool {get set}
    var cheese: Bool {get set}
    var pickles: Bool {get set}
    var ketchup: Bool {get set}
    var mustard: Bool {get set}
    var lettuce: Bool {get set}
    var tomato: Bool {get set}
}

class HamBurgerBuilder: BurgerBuilder {
    var name = "Burger"
    var patties = 1
    var bacon = false
    var cheese = false
    var pickles = true
    var ketchup = true
    var mustard = true
    var lettuce = false
    var tomato = false
}

class CheeseBurgerBuilder: BurgerBuilder {
    var name = "CheeseBurger"
    var patties = 1
    var bacon = false
    var cheese = true
    var pickles = true
    var ketchup = true
    var mustard = true
    var lettuce = false
    var tomato = false
}

var myBurgerBuilder = HamBurgerBuilder()
var myBurger = Burger(builder: myBurgerBuilder)
myBurger.showBurger()

var myCheeseBurgerBuilder = CheeseBurgerBuilder()
myCheeseBurgerBuilder.tomato = true
var myCheeseBurger = Burger(builder: myCheeseBurgerBuilder)
myCheeseBurger.showBurger()


