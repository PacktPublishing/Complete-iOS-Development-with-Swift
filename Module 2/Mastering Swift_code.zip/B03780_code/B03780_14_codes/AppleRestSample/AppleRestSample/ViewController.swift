//
//  ViewController.swift
//  AppleRestSample
//
//  Created by Jon Hoffman on 3/10/15.
//  Copyright (c) 2015 Jon Hoffman. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        var printResultsClosure: HttpConnect.dataFromURLCompletionClosure = {

            if let data = $1 {
                var sString = NSString(data: data, encoding: NSUTF8StringEncoding)
                println(sString)
            } else {
                println("Data is nil")
            }
        }
        var aConnect = HttpConnect()
        aConnect.getConnect(printResultsClosure)

    //            aConnect.postConnect(printResultsClosure);
  
        var reachable = aConnect.networkConnectionType("packtpub.com")
        switch (reachable) {
        case HttpConnect.ConnectionType.MOBILE3GNETWORK:
            println("Mobile Connection")
        case HttpConnect.ConnectionType.WIFINETWORK:
            println("WIFI Conenction")
        default:
            println("No Connection")
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }


}

