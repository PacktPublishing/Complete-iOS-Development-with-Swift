//
//  AppleConnect.swift
//  AppleRestSample
//
//  Created by Jon Hoffman on 3/10/15.
//  Copyright (c) 2015 Jon Hoffman. All rights reserved.
//

import UIKit
import SystemConfiguration

public class HttpConnect: NSObject {
    
    public enum ConnectionType {
        case NONETWORK
        case MOBILE3GNETWORK
        case WIFINETWORK
    }
    
    public typealias dataFromURLCompletionClosure = (NSURLResponse!, NSData!) -> Void
    
    public func getConnect(handler: dataFromURLCompletionClosure) {
        var queue = NSOperationQueue()
        var sessionConfiguration = NSURLSessionConfiguration.defaultSessionConfiguration();
        
        var urlString = "https://itunes.apple.com/search?term=jimmy+buffett"
        
        if let encodeString = urlString.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding) {
            if let url: NSURL = NSURL(string: encodeString) {
                
                var request = NSMutableURLRequest(URL:url)
                request.HTTPMethod = "GET"
                var urlSession = NSURLSession(configuration:sessionConfiguration, delegate: nil, delegateQueue: queue)
                
                var sessionTask = urlSession.dataTaskWithRequest(request) {
                    (data, response, error) in
                    
                    handler(response, data)
                }
                sessionTask.resume()
            }
        }
        
    }
    
    public func postConnect(handler: dataFromURLCompletionClosure) {
        var queue = NSOperationQueue()
        
        var sessionConfiguration = NSURLSessionConfiguration.defaultSessionConfiguration()
        
        var urlString = "http://httpbin.org/post"
        if let encodeString = urlString.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding){
            if let url: NSURL = NSURL(string: encodeString) {
                
                var request = NSMutableURLRequest(URL:url)
                request.HTTPMethod = "POST"
                var params = dictionaryToQueryString(["One":"1 and 1", "Two":"2 and 2"])
                request.HTTPBody = params.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
                var urlSession = NSURLSession(configuration:sessionConfiguration, delegate: nil, delegateQueue: queue)
                
                var sessionTask = urlSession.dataTaskWithRequest(request) {
                    (data, response, error) in
                    
                    handler(response, data)
                }
                sessionTask.resume()
            }
        }
    }
    
    private func dictionaryToQueryString(dict: [String : String]) -> String {
        var parts = [String]()
        for (key, value) in dict {
            var part : String = key + "=" + value
            parts.append(part);
        }
        //hoping to eventually remove this bridge but Swift array does not have componentsJoinedBy
        
        var arr : NSArray = parts
        return arr.componentsJoinedByString("&")
        
    }
    
    public func networkConnectionType(hostname: NSString) -> ConnectionType {
        
        var reachabilityRef = SCNetworkReachabilityCreateWithName(nil,hostname.UTF8String)
        
        var reachability = reachabilityRef.takeUnretainedValue()
        var flags: SCNetworkReachabilityFlags = 0
        SCNetworkReachabilityGetFlags(reachabilityRef.takeUnretainedValue(), &flags)
        
        var reachable: Bool = (flags & UInt32(kSCNetworkReachabilityFlagsReachable) != 0)
        var needsConnection: Bool = (flags & UInt32(kSCNetworkReachabilityFlagsConnectionRequired) != 0)
        if reachable && !needsConnection {
            // determine what type of connection is available
            var isCellularConnection = (flags & UInt32(kSCNetworkReachabilityFlagsIsWWAN) != 0)
            if isCellularConnection {
                return ConnectionType.MOBILE3GNETWORK // cellular connection available
            } else {
                return ConnectionType.WIFINETWORK // wifi connection available
            }
        }
        return ConnectionType.NONETWORK // no connection at all
    } 
}
