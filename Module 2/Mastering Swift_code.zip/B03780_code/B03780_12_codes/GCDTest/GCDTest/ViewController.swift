//
//  ViewController.swift
//  GCDTest
//
//  Created by Jon Hoffman on 2/16/15.
//  Copyright (c) 2015 Jon Hoffman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        var cQueueExample = ConcurrentQueues()
        cQueueExample.example()
        
        var sQueueExample = SerialQueues()
        sQueueExample.example()
        
        var dPatchOnce = DispatchOnce()
        for i in 0..<4 {
            dPatchOnce.example()
        }
        
        var dPatchAfter = DispatchAfter()
        dPatchAfter.example()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

