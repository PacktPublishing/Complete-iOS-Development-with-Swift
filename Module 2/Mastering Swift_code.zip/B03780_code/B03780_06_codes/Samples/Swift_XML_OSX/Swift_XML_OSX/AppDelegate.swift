//
//  AppDelegate.swift
//  Swift_XML_OSX
//
//  Created by Jon Hoffman on 12/27/14.
//  Copyright (c) 2014 Jon Hoffman. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(aNotification: NSNotification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }


}

