//
//  Author.swift
//  Swift_XML_JSON
//
//  Created by Jon Hoffman on 12/24/14.
//  Copyright (c) 2014 Jon Hoffman. All rights reserved.
//

import UIKit

class Author {
    var name = ""
    var publisher = ""
    var books: [String] = []
}
