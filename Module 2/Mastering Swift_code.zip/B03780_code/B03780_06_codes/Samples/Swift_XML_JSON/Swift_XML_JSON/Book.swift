//
//  Book.swift
//  Swift_XML_JSON
//
//  Created by Jon Hoffman on 12/24/14.
//  Copyright (c) 2014 Jon Hoffman. All rights reserved.
//

import UIKit

class Book {
    var name = ""
    var category = ""
    var description = ""
   
}
