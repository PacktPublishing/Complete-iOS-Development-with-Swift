// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

extension String {
    
    var firstLetter: Character {
        get {
            var letters = Array(self)
            return letters[0]
        }
    }
    
    func reverse() -> String {
        var reverse = ""
        for letter in self {
            reverse = "\(letter)" + reverse
        }
        return reverse
    }
}


var myString = "Learning Swift is fun"
println(myString.reverse())
println(myString.firstLetter)

