//
//  MyClass.swift
//  TestArcProject
//
//  Created by Jon Hoffman on 12/22/14.
//  Copyright (c) 2014 Jon Hoffman. All rights reserved.
//

import UIKit

class MyClass {
    var name = ""
    init(name: String) {
        self.name = name
        println("Initializing class with name \(self.name)")
    }
    deinit {
        println("Releaseing class with name \(self.name)")
    }
   
}
