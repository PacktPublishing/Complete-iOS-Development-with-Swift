//
//  MyObject.h
//  TestObjectiveC
//
//  Created by Jon Hoffman on 1/4/15.
//  Copyright (c) 2015 Jon Hoffman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyObject : NSObject

-(int)myMethodWithValue:(int)i;

@end
