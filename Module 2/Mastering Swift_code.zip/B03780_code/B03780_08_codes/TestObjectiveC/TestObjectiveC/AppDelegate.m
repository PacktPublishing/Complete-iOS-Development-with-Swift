//
//  AppDelegate.m
//  TestObjectiveC
//
//  Created by Jon Hoffman on 1/4/15.
//  Copyright (c) 2015 Jon Hoffman. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end
