//
//  AppDelegate.h
//  TestObjectiveC
//
//  Created by Jon Hoffman on 1/4/15.
//  Copyright (c) 2015 Jon Hoffman. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

