// Playground - noun: a place where people can play

import UIKit

var x = 1
var y = 1
var z = 1

//Single conditional statement, no parentheses
if x == 1 {
    println("X == 1")
}

//Multiple conditional statements, parentheses
if (x == 1) && (y == 1) && (z == 1) {
    println("All vars == 1")
}

//Multipe conditional statememnts, no Parentheses
if x == 1 && y == 1 && z == 1 {
    println("All vars == 1")
}
