// Playground - noun: a place where people can play

import UIKit

println("Hello from Swift")
println("Hello from Swift");
