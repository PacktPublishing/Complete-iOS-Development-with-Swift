// Playground - noun: a place where people can play

import UIKit

//The i block
var i=1
if i==1 {
    println("HI")
}

//The j block
var j = 1
if j == 1 {
    println("HI")
}
