// Playground - noun: a place where people can play

import UIKit

var name = "Jon"
var language = "Swift"

var message1 = name + " Welcome to the wonderful world of " + language + "!"
var message2 = "\(name) Welcomd to the wonderful world of \(language)!"

println(message1)
println(message2)
