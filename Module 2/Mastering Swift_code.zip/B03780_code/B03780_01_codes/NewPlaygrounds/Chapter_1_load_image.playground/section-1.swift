// Playground - noun: a place where people can play

import UIKit


var image = UIImage(named: "swift.png")
