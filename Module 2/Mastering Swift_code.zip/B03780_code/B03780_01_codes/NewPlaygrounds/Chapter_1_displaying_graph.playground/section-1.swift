// Playground - noun: a place where people can play

import UIKit

var j = 1
for i in 1...5 {
    j*=i
}
