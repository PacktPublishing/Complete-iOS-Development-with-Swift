// Playground - noun: a place where people can play

import UIKit

var i = 1

if i = 1 {
    println("HI")
}

while i = 1 {
    println("HI")
    i = 2
}
