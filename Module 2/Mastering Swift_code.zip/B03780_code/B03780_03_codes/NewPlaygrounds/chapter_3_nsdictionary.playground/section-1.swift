// Playground - noun: a place where people can play

import UIKit

var nsdic: NSDictionary = ["one":"HI", "two":"There"]
if let dic = nsdic as? [String: String] {
    var newdic = dic as [String:String]
}

var nsdic2: NSDictionary = ["one":"HI", "two":2]
if let dic2 = nsdic2 as? [String:String] {
    var newdic2 = dic2 as [String:String]
}
