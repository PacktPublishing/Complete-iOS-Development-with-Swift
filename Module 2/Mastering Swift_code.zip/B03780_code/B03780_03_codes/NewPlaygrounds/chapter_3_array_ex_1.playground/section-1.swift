// Playground - noun: a place where people can play

import UIKit

let arrayOne = [1,2,3]

var arrayTwo = [4,5,6]

var arrayThree = [Int]()

var arrayFour = [Int](count: 7, repeatedValue: 3)

var multiArrayOne = [[1,2],[3,4],[5,6]]var multiArrayTwo = [[Int]]()

