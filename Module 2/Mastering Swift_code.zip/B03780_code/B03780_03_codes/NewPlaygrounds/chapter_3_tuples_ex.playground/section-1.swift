// Playground - noun: a place where people can play

import UIKit

var team = ("Boston", "Red Sox", 97, 65, 0.599)
var (city, name, wins, loses, percent) = team

var team2 = (city:"Boston", name:"Red Sox", wins:97, loses:65, percent:0.599)


