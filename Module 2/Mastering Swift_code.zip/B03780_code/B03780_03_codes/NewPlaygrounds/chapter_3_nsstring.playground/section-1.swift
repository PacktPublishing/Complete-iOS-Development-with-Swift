// Playground - noun: a place where people can play

import UIKit

var str = "http://www.packtpub.com"
var path = str.stringByAppendingPathComponent("swift")

var nsstr: NSString = "1234"
var num = (nsstr as String).toInt() //num contains the number 1234
