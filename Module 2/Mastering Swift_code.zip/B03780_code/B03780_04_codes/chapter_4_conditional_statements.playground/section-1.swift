// Playground - noun: a place where people can play

import UIKit

var teamOneScore = 7
var teamTwoScore = 6
if teamOneScore > teamTwoScore {
    println("Team One Won")
} else if teamTwoScore > teamOneScore  {
    println("Team Two Won")
} else {
    println("We have a tie")
}
