// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func sayHello(greeting: String, names: String...) {
    for name in names {
        println("\(greeting) \(name)")
    }
}


sayHello("Hello", "Jon","Kim")
