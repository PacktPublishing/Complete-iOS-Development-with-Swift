// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


func getNames() -> [String] {
    var retArray = ["Jon", "Kim", "Kailey", "Kara"]
    return retArray
}

func getTeam() -> (team: String, wins: Int, percent: Double) {
    let retTuple = ("Red Sox", 99, 0.611)
    return retTuple
}


var names = getNames()

var t = getTeam()

println("\(t.team) had \(t.wins) wins")
