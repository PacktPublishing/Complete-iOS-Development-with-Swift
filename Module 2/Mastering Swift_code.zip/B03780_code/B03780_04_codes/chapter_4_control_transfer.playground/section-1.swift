// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

for i in 1...10 {
    if i%2 == 0 {
        continue
    }
    println("\(i) is odd")
}

for i in 1...10 {
    if i%2 == 0 {
        break
    }
    println("\(i) is odd")
}


var name = "Jon"var sport = "Baseball"switch sport {case "Baseball":    println("\(name) playes Baseball")    fallthroughcase "Basketball":    println("\(name) playes Basketball")    fallthroughdefault:    println("Unknown sport")}
