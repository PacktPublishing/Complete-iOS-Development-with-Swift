// Playground - noun: a place where people can play

import UIKit

for var index = 1, i = 2; index<=4; index++ {
    println(index)
}


var countries = ["USA","UK", "IN"]
for var index = 0; index < countries.count; index++ {
    println(countries[index])
}

var dic = ["USA": "United States", "UK": "United Kingdom", "IN":"India"]
var keys  = dic.keys.array
for var index = 0; index < keys.count; index++ {
    println(dic[keys[index]]);
}


for index in 1...5 {
    println(index)
}

for item in countries {
    println(item)
}

for (abbr, name) in dic {
    println("\(abbr) --  \(name)")
}


var ran = 0
while ran < 4 {
    ran = Int(arc4random() % 5)
}

var ran2: Int
do {
    ran2 = Int(arc4random() % 5)
} while ran2 < 4
