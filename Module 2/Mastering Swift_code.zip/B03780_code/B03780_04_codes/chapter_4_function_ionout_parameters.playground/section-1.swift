// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func reverse(inout first: String, inout second: String) {
    var tmp = first
    first = second
    second = first
}

var one = "One"
var two = "Two"
reverse(&one, &two)
println("one: \(one)  two: \(two)")
