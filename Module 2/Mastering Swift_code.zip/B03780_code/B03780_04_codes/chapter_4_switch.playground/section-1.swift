// Playground - noun: a place where people can play

import UIKit

var speed = 300000000
switch speed {
    case 300000000:
        println("Speed of Light")
    case 340:
        println("Speed of soud")
    default:
        println("Unknown Speed")
}


var char : Character = "e"
switch char {
    case "a", "e", "i", "o", "u":
            println("letter is a vowel")
    case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m","n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
            println("letter is a consonant")
    default:
            println("unknown letter")
}


var grade = 93switch grade {    case 90...100:        println("Grade is an A")    case 80...89:        println("Grade is a B")    case 70...79:        println("Grade is an C")    case 60...69:        println("Grade is a D")    case 0...59:        println("Grade is a F")    default:        println("Unknown Grade")}


var studentId = 4var grade2 = 57switch grade2 {    case 90...100:        println("Grade is an A")    case 80...89:        println("Grade is a B")    case 70...79:        println("Grade is an C")    case 55...69 where studentId == 4:        println("Grade is a D for student 4")    case 60...69:        println("Grade is a D")    case 0...59:        println("Grade is a F")    default:       println("Unknown Grade")
}



studentId = 4var grade3 = 57switch grade3 {    case 90...100:        println("Grade is an A")    case 80...89:        println("Grade is a B")    case 70...79:        println("Grade is an C")    case 60...69:        println("Grade is a D")    case 0...59:        println("Grade is a F")        //The follow case statement would never be reached because the        //grades would always match one of the previous two    case 55...69 where studentId == 4:        println("Grade is a D for student 4")    default:        println("Unknown Grade")}
