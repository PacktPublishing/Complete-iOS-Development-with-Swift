// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

class MyNames {
    private var names:[String] = ["Jon", "Kim", "Kailey", "Kara"]
    
    var number: Int {
        get {
            return names.count
        }
    }
    
    subscript(add name: String) -> String{
        names.append(name)
        return name
    }
    
    subscript(index: Int) -> String {
        get {
            return names[index]
        }
        set {
            names[index] = newValue
        }
    }
}


var names = MyNames()
names[add: "Buddy"]
for var i=0; i<names.number; i++ {
    println(names[i])
}

println(names[0])
names[0] = "Buddy"
println(names[0])
