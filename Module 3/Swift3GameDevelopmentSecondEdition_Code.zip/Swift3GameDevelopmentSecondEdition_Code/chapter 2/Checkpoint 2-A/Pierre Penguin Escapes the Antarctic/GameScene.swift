//
//  GameScene.swift
//  Pierre Penguin Escapes the Antarctic
//
//  Created by Stephen Haney on 7/5/16.
//  Copyright © 2016 JoyfulGames.io. All rights reserved.
//

import SpriteKit

class GameScene: SKScene {
    override func didMove(to view: SKView) {
    }
}
